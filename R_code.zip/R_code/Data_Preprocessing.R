library(dplyr)
library(vegan)
library(coda.base)
library(readxl)
library(tibble)

# Initial settings
criteria = 0.005 
pseudocount = 1e-06
indep_vars = c("Age", "Gender", "BMI")
BATCH = "Batch"

# Data preprocessing
## (1) NA filtering
NA_counts <- sapply(count_matrix_covar[indep_vars], function(x) sum(is.na(x)))
total_NA <- sum(NA_counts)

## (2) OTU frequency filtering
OTU_table <- samplebyotu_countmatrix
OTU_sum <- colSums(samplebyotu_countmatrix)
OTU_freq <- OTU_sum / sum(OTU_sum)
filtered_OTU <- which(OTU_freq > criteria * 1e-6)
samplebyotu_countmatrix <- samplebyotu_countmatrix[, filtered_OTU]

## (3) Remove zero samples and OTUs
rm_zero <- function(otu_table) {
  otu_table <- otu_table[, colSums(otu_table) > 0]  # Remove zero OTUs
  otu_table <- otu_table[rowSums(otu_table) > 0, ]  # Remove zero samples
  return(otu_table)
}
samplebyotu_countmatrix <- rm_zero(samplebyotu_countmatrix)

## (4) Filtering non-zero samples with unique batch condition
error_taxon <- Filter(function(taxon) length(unique(count_merged$Batch[samplebyotu_countmatrix[, taxon] > 0])) == 1, colnames(samplebyotu_countmatrix))
samplebyotu_countmatrix <- samplebyotu_countmatrix[, !colnames(samplebyotu_countmatrix) %in% error_taxon]

## (5) Constant OTU filtering
filtered_constantotu_data <- samplebyotu_countmatrix[, apply(samplebyotu_countmatrix, 2, function(x) !(all(x == 0) || all(x != 0)))]

constant_OTU_filter <- function(otu_table) {
  otu_table <- otu_table[, apply(otu_table, 2, function(x) !(all(x == min(x)) || all(x == max(x))))]
  return(otu_table)
}

otu_filtered <- rm_zero(filtered_constantotu_data)
meta_datasetselected <- count_matrix_covar %>% filter(ID %in% rownames(otu_filtered))
samplebyotu_countmatrix <- rownames_to_column(as.data.frame(otu_filtered), var="ID")

# check missing ID before analyzing or merging
otu_filtered_total_df <- inner_join(samplebyotu_countmatrix, meta_datasetselected, by="ID")
otu_filtered_total_df <- inner_join(otu_filtered_total_df, clinicalinfo_total[,c("ID","Batch")], by = "ID")
otu_final <- otu_filtered[ ,which(apply(otu_filtered, 2, function(x) !(all(x == 0) || all(x != 0))))]

