###############################################
# Background functions
###############################################
library(ade4)
library(vegan)
library(ggplot2)
library(gridExtra)
library(cluster)
library(compositions)

rm_zero <- function(otu_table){
  # remove zero samples 
  otu_1 <- otu_table
  zero_col_idx <- as.integer(which(apply(otu_1, 1, sum) == 0))
  if(length(zero_col_idx) > 0) {
    print(paste0("zero count samples removed: ", as.character(length(zero_col_idx))))
    otu_with_ID_ch1 <- otu_table[,-zero_col_idx]
  }else{
    print("no zero count samples")
    otu_with_ID_ch1 <- otu_table
  }
  otu_2 <- otu_with_ID_ch1
  zero_row_idx <- as.integer(which(apply(otu_2, 1, sum) == 0))
  if(length(zero_row_idx) > 0){
    print(paste0("zero count OTUs removed: ", as.character(length(zero_row_idx))))
    otu_with_ID_ch2 <- otu_with_ID_ch1[-zero_row_idx,]
  }else{
    print("no zero count OTU")
    otu_with_ID_ch2 <- otu_with_ID_ch1
  }
  otu_rm_zero <- otu_with_ID_ch2
  return(otu_with_ID_ch2)
}

PERMANOVA_R2 <- function(table, batch){
  pseudocount = 1e-06 
  res <- list()
  dissim <- c("bray", "aitchison","manhattan","canberra")
  for(d in dissim){
    message(d)
    if (d == "bray") {
      bray_dist <- vegdist(table, method = "bray")
      res[[d]] <- adonis2(bray_dist ~ batch)$R2[1]
    } else {
      if (d=="aitchison") {table = table + pseudocount}
      res[[d]] <- (vegan::adonis2(table~batch,
                                  method = d, na.rm=T))$R2[1]
    }
  }
  return(res)
}

# Function to plot Principal Coordinates Analysis (PCoA)
Plot_PCoA <- function(TAX, factor, sub_index = NULL, dissimilarity = "Bray", GUniFrac_type = "d_0.5", tree = NULL, main = NULL, aa = 1.5, xlim = NULL, ylim = NULL) {
  # Determine number of factor levels
  nfactor = length(table(factor))
  
  # Default sub_index to all columns if not specified
  if (is.null(sub_index)) {
    sub_index = seq(ncol(TAX))
  }
  
  # Internal function to handle the plotting
  plot_function <- function(PCoA, fac, main, aa, nfactor, xlim, ylim) {
    s.class(PCoA, fac = as.factor(fac), col = 1:nfactor, grid = FALSE, sub = main, csub = aa)
    if (!is.null(xlim)) {
      par(new = TRUE)
      plot(PCoA, xlim = xlim, ylim = ylim, type = "n", xlab = "", ylab = "")
      s.class(PCoA, fac = as.factor(fac), col = 1:nfactor, grid = FALSE, add.plot = TRUE)
    }
  }
  
  if (dissimilarity == "Bray") {
    index = which(apply(TAX[, sub_index], 1, sum) > 0)
    PCoA = cmdscale(vegdist(TAX[index, sub_index]), k = 4)
    plot_function(PCoA, factor[index], main, aa, nfactor, xlim, ylim)
    
  } else if (dissimilarity == "Aitch") {
    Z = clr(as.matrix(TAX[, sub_index]) + 0.5)
    PCoA = cmdscale(vegdist(Z, method = "euclidean"), k = 4)
    plot_function(PCoA, factor, main, aa, nfactor, xlim, ylim)
    
  } else if (dissimilarity == "GUniFrac") {
    valid_types <- c("d_0", "d_0.5", "d_1", "d_UW", "d_VAW")
    if (!GUniFrac_type %in% valid_types) stop("Invalid GUniFrac type. Use one of: ", paste(valid_types, collapse=", "))
    
    index = which(apply(TAX[, sub_index], 1, sum) > 0)
    unifracs = GUniFrac(TAX[index, sub_index], tree, alpha = c(0, 0.5, 1))$unifracs
    PCoA = cmdscale(unifracs[, , GUniFrac_type], k = 4)
    plot_function(PCoA, factor[index], main, aa, nfactor, xlim, ylim)
    
  } else {
    valid_methods <- c("manhattan", "canberra")
    if (!dissimilarity %in% valid_methods) stop("Invalid dissimilarity. Use one of: ", paste(valid_methods, collapse=", "))
    
    index = which(apply(TAX[, sub_index], 1, sum) > 0)
    PCoA = cmdscale(vegdist(TAX[index, sub_index], method = dissimilarity), k = 4)
    plot_function(PCoA, factor[index], main, aa, nfactor, xlim, ylim)
  }
}

data_list <- list()
# Generate PCoA plots for each combination of data and dissimilarity method
for (name in names(data_list)) {
  for (method in distance_metrics) {
    plot <- tryCatch({
      Plot_PCoA(
        TAX = data_list[[name]],
        factor = batch,
        dissimilarity = method
      )
    }, error = function(e) {
      message("Error generating plot for ", name, " - ", method, ": ", e$message)
      NULL
    })
    
    # Add plot to the list if it was successfully generated
    if (!is.null(plot)) {
      plots[[paste(name, method, sep = "_")]] <- plot
    }
  }
}
  
# Function to calculate Silhouette coefficient
  calculate_aitchison_distance <- function(data) {
    data_clr <- clr(data)  # Center log-ratio transformation
    dist_matrix <- dist(data_clr)  # Compute distance matrix
    return(dist_matrix)
  }
  
  # Function to calculate Silhouette Coefficient, evaluating clustering quality
  calculate_silhouette <- function(data, batch, method) {
    # Select distance calculation method based on input
    distance_matrix <- if (method == "aitchison") {
      calculate_aitchison_distance(data)
    } else {
      vegdist(data, method = method)  # Calculate ecological distances
    }
    silhouette_values <- silhouette(batch, as.dist(distance_matrix))  # Compute silhouette values
    mean_silhouette <- mean(silhouette_values[, 3])  # Average silhouette width
    return(mean_silhouette)
  }
  
  # Empty data frame to store results for each data set and distance method
  results <- data.frame(
    Data = character(),
    Distance = character(),
    Mean_Silhouette = numeric(),
    stringsAsFactors = FALSE
  )
  
  # Loop over each data set and distance method to compute Silhouette Coefficients
  for (name in names(data_list)) {
    for (method in methods) {
      mean_silhouette <- calculate_silhouette(data_list[[name]], batch, method)
      results <- rbind(results, data.frame(Data = name, Distance = method, Mean_Silhouette = mean_silhouette))
    }
  }

  
  
  }